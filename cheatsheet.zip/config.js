module.exports = {
    ARN   : "arn:aws:lambda:us-east-1:282766053803:function:presentation_demo",
    APP_ID: "amzn1.ask.skill.3a627128-495e-4d82-9763-526e2f747e96"
}